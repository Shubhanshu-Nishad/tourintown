<div class="copyrights">
	 <p>© 2021 metaedcuators. All Rights Reserved |  <a href="#">Metaedcuators</a> </p>
</div>	
